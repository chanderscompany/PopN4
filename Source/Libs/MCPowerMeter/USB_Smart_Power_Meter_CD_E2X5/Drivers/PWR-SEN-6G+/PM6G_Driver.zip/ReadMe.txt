 USB Driver is required only up to serial Number: 11010000000.
 Units with Serial Number above 11010000000 are based on HID USB and
 USB driver installation is not required.
 DelcomDLL.dll file is required to be located on Windows System folder for supportting Power Sensor model PWR-SEN-6G+. 